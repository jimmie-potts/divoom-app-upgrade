import {validateEvent,validDisplayText} from '@jimmie-potts/agent-lifecycle-contracts';
import {enrichCodexTitle} from '@jimmie-potts/agent-state/providers';
import {readFile} from 'node:fs/promises';
import {createServer, type IncomingMessage, type ServerResponse} from 'node:http';
import {isIPv4} from 'node:net';
import {createHash, randomBytes, randomUUID, timingSafeEqual} from 'node:crypto';
import {createAgentState, type Consumer, type Identity, type DurableState} from '@jimmie-potts/agent-state';
import {HubStorage, type HubLease} from './storage.js';
import {ControllerClient, type ControllerConfig} from './controllers.js';
import {prepareActivation,type ActivationPlan} from './migration-routes.js';
import {consumeReleasedState,type ReleasedState} from './migration.js';
import {createHubMcp, HOST_SERVICE, type HubMcp} from './mcp.js';
import {startBrowserLaunch} from './browser-launch.js';
import {HttpError, canonical, exact, id, object} from './common.js';
import {createReplayLedgers} from './replay.js';
import {archivedSession,codexDesktopOptions,startDesktopRead,type CodexDesktopOptions} from './codex-desktop.js';
import {createPlayback,type PlaybackSource} from './playback.js';
import {createSonySource,sonyConfiguration} from './sony.js';
import {createSonosSource,sonosConfiguration} from './sonos.js';

type Scope = 'read'|'ingest'|'control'|'admin';
export type Credential = {id:string; digest:string; scopes:Scope[]; devices:string[]};
export type HubOptions = {directory:string; ownerId:string; consumers:Consumer[]; credentials:Credential[]; controllers:ControllerConfig[]; port?:number; editorLinks?:Record<string,string>; mcp?:boolean; codexDesktop?:CodexDesktopOptions; playback?:{id:string; sources:unknown[]}; browserAccess?:'trusted-loopback'; clock?:()=>number; feedIntervalMs?:number};

function credentials(input: Credential[]): Credential[] {
  if (!Array.isArray(input) || input.length < 1 || input.length > 32 || new Set(input.map(c => c.id)).size !== input.length ||
      new Set(input.map(c => c.digest)).size !== input.length || input.some(c => !id(c.id) || !/^[a-f0-9]{64}(?![\s\S])/.test(c.digest) ||
        !Array.isArray(c.scopes) || c.scopes.length > 4 || c.scopes.some(s => !['read','ingest','control','admin'].includes(s)) ||
        !Array.isArray(c.devices) || c.devices.length > 16 || c.devices.some(d => !id(d)))) throw new Error('invalid-credentials');
  return structuredClone(input);
}
function json(res: ServerResponse, status: number, value: unknown) {
  if (res.destroyed) return;
  res.writeHead(status,{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'});
  res.end(JSON.stringify(value));
}
/**
 * Builds the configured sources in preference order under one client-facing playback ID. That ID shares credential device
 * grants with controller aliases and never changes with the presented source.
 */
function playbackSources(value: unknown, aliases: string[]): {id:string; sources:PlaybackSource[]} {
  if (!object(value) || !exact(value,['id','sources']) || !id(value.id) || aliases.includes(value.id) || value.id === HOST_SERVICE || isIPv4(value.id) ||
      !Array.isArray(value.sources) || value.sources.length < 1 || value.sources.length > 2) throw new Error('invalid-playback');
  const kinds = new Set<string>(), sources: PlaybackSource[] = [];
  for (const entry of value.sources) {
    if (!object(entry) || typeof entry.kind !== 'string' || kinds.has(entry.kind)) throw new Error('invalid-playback');
    kinds.add(entry.kind);
    const config = entry.kind === 'sony' ? sonyConfiguration(entry) : entry.kind === 'sonos' ? sonosConfiguration(entry) : undefined;
    if (!config) throw new Error('invalid-playback');
    // The playback ID is returned to clients, so it must not carry a speaker address.
    if (value.id.includes(new URL(config.endpoint).hostname)) throw new Error('invalid-playback');
    sources.push(config.kind === 'sony' ? createSonySource(config) : createSonosSource(config));
  }
  return {id:value.id,sources};
}
async function body(req: IncomingMessage, maximum: number): Promise<unknown> {
  if (req.headers['content-type']?.split(';')[0] !== 'application/json' || req.headers['content-encoding']) throw new HttpError('invalid-input',400);
  if (Number(req.headers['content-length'] ?? 0) > maximum) throw new HttpError('capacity',413);
  const chunks: Buffer[] = []; let size = 0;
  for await (const chunk of req) {
    size += chunk.length; if (size > maximum) throw new HttpError('capacity',413); chunks.push(chunk);
  }
  let value: unknown;
  try { value = JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks))); }
  catch { throw new HttpError('invalid-input',400); }
  const pending: [unknown,number][] = [[value,0]]; let nodes = 0;
  while (pending.length) {
    const [item,depth] = pending.pop()!;
    if (++nodes > 10000 || depth > 20) throw new HttpError('invalid-input',400);
    if (item && typeof item === 'object') for (const child of Object.values(item)) pending.push([child,depth+1]);
  }
  return value;
}

export async function startHub(options: HubOptions, migration?:{staged:true;released?:ReleasedState}) {
  if (migration !== undefined && (!object(migration) || migration.staged !== true || Object.keys(migration).some(key=>!['staged','released'].includes(key)))) throw new Error('invalid-migration');
  const imported = migration?.released ? consumeReleasedState(migration.released) : undefined;
  let staged = migration?.staged === true;
  let activationAllowed = imported !== undefined;
  let activating = false;
  let preparingConsumers = false;
  if (options.mcp !== undefined && typeof options.mcp !== 'boolean') throw new Error('invalid-configuration');
  // Hub #276: the owner's opt-in to sign any same-origin loopback page in without a launch code.
  if (options.browserAccess !== undefined && options.browserAccess !== 'trusted-loopback') throw new Error('invalid-configuration');
  const codexDesktop = options.codexDesktop === undefined ? undefined : codexDesktopOptions(options.codexDesktop);
  let currentCredentials = credentials(options.credentials);
  if (!Array.isArray(options.controllers) || options.controllers.length > 16 || new Set(options.controllers.map(c => c.id)).size !== options.controllers.length ||
      new Set(options.controllers.map(c => c.controllerId + ':' + c.deviceId)).size !== options.controllers.length ||
      (options.port !== undefined && (!Number.isInteger(options.port) || options.port < 0 || options.port > 65535)) ||
      (options.feedIntervalMs !== undefined && (!Number.isInteger(options.feedIntervalMs) || options.feedIntervalMs < 1 || options.feedIntervalMs > 86400000))) throw new Error('invalid-configuration');
  const playbackConfig = options.playback === undefined ? undefined : playbackSources(options.playback,options.controllers.map(c => c.id));
  const playbackId = playbackConfig?.id;
  const editorLinks:Record<string,string> = {};
  if (options.editorLinks !== undefined) {
    if (!object(options.editorLinks) || Object.keys(options.editorLinks).length > 16) throw new Error('invalid-editor-links');
    for (const [alias,href] of Object.entries(options.editorLinks)) {
      const link = new URL(href);
      if (!options.controllers.some(c=>c.id===alias) || link.protocol!=='http:' || link.hostname!=='127.0.0.1' || link.username || link.password || link.search || link.hash) throw new Error('invalid-editor-links');
      editorLinks[alias]=link.href;
    }
  }
  const clients = new Map(options.controllers.map(config => [config.id,new ControllerClient(config)]));
  let lease: HubLease | undefined;
  const storage = new HubStorage(options.directory);
  const owner = await createAgentState({ownerId:options.ownerId,consumers:options.consumers,
    ...(codexDesktop?{isArchived:(identity:Identity,signal:AbortSignal,ancestors:readonly Identity[])=>archivedSession(codexDesktop,identity,signal,ancestors)}:{}),
    ...(options.clock ? {clock:options.clock} : {}),...(imported === undefined ? {} : {importState:imported}),storage:{acquire:async (ownerId,signal) => {
    lease = await storage.acquire(ownerId,signal) as HubLease;
    if (lease.fenced() && !staged) { await lease.release(); throw new Error('owner-quiesced'); }
    if (staged) lease.setFence(true);
    return lease;
  }}}).catch(async error => {
    // Keep a stable operator error without exposing database paths.
    const probe = await storage.acquire(options.ownerId,new AbortController().signal).catch(() => null) as HubLease | null;
    if (probe) { const fenced = probe.fenced(); await probe.release(); if (fenced) throw new Error('owner-quiesced'); }
    throw error;
  });
  const snapshot = (version:'1.0'|'1.1'|'1.2'='1.0') => {const value=owner.snapshot(version);return staged && !preparingConsumers && value.collector==='running' ? {...value,collector:'quiesced' as const} : value;};
  const replay = createReplayLedgers();
  let exported: Promise<DurableState> | undefined;
  const streams = new Set<ServerResponse>();
  const streamOwners = new Map<ServerResponse,string>();
  let active = 0, rejected = 0, closing = false;
  let origin = '', hosts: string[] = [];
  let mcp: HubMcp | undefined;
  let playback: ReturnType<typeof createPlayback> | undefined;
  let closeBrowserLaunch: (()=>Promise<void>) | undefined;
  const launchCodes=new Map<string,number>();
  const browserSessions=new Map<string,{credential:Credential;expires:number}>();
  // The one retirement path for expiry, eviction, logout, credential replacement and shutdown. Repeating it is harmless.
  // Admitted commands keep running and stay charged until they settle; nothing is cancelled or sent again.
  const retireBrowser=(digest:string)=>{
    const session=browserSessions.get(digest);if(!session)return;
    browserSessions.delete(digest);replay.retire(session.credential.id);
    for(const [stream,holder] of streamOwners)if(holder===session.credential.id)stream.destroy();
  };
  const pruneBrowser=()=>{
    const now=Date.now();
    for(const [code,expiry] of launchCodes)if(expiry<=now)launchCodes.delete(code);
    for(const [hash,session] of browserSessions)if(session.expires<=now)retireBrowser(hash);
  };
  // The launch exchange and the trusted-loopback route issue the same session, so their grants, expiry and cap cannot drift.
  const openBrowserSession=()=>{
    // A request admitted before shutdown may finish reading its body afterwards; it must not outlive the shutdown retirement.
    if(closing)throw new HttpError('unavailable',503);
    if(browserSessions.size>=16)retireBrowser(browserSessions.keys().next().value!);
    const token=randomBytes(32).toString('base64url');
    const credential:Credential={id:'browser-'+randomUUID(),digest:createHash('sha256').update(token).digest('hex'),scopes:['read','control'],devices:[...clients.keys(),...(playbackId ? [playbackId] : [])]};
    browserSessions.set(credential.digest,{credential,expires:Date.now()+8*60*60*1000});
    return {token,expiresInSeconds:8*60*60};
  };
  // Host is one of the loopback names and any Origin names that same host, so a rebinding page, or a page on the other loopback name, is refused.
  const sameOrigin=(req:IncomingMessage,{requireOrigin=false,sites=[undefined,'none','same-origin']}:{requireOrigin?:boolean;sites?:(string|undefined)[]}={})=>
    hosts.includes(req.headers.host ?? '') && (req.headers.origin === undefined ? !requireOrigin : req.headers.origin === 'http://' + req.headers.host) &&
    sites.includes(req.headers['sec-fetch-site'] as string | undefined);
  const issueLaunch=()=>{
    if(closing)throw new Error('host-closing');
    pruneBrowser();if(launchCodes.size>=8)throw new Error('launch-capacity');
    const code=randomBytes(32).toString('base64url');launchCodes.set(code,Date.now()+30000);
    return {url:origin,code};
  };
  const feedEpoch = randomUUID();let feedSequence = 0, feedSignature = '';
  const feedHistory: {sequence:number; body:string}[] = [];
  const streamState = new Map<ServerResponse,{req:IncomingMessage; lastSequence?:number; blockedAt:number}>();
  // Recomputed at most once per notification/tick, then written to every open stream.
  const advanceFeed = () => {
    const state = snapshot();
    const projection = {apiVersion:'1.0',ownerId:options.ownerId,revision:state.revision,connection:'current',collector:state.collector,lossCount:state.lossCount,admissionRejected:rejected,uncertain:state.sessions.filter(s => s.freshness === 'uncertain').length};
    const fingerprint = JSON.stringify(projection);
    if (fingerprint !== feedSignature) {
      feedSignature = fingerprint;feedSequence++;
      feedHistory.push({sequence:feedSequence,body:`id: ${feedEpoch}:${feedSequence}\nevent: state\ndata: ${fingerprint}\n\n`});
      if (feedHistory.length > 32) feedHistory.shift();
    }
  };
  const deliverFeed = (res: ServerResponse) => {
    const state = streamState.get(res);if (!state) return;
    try { authorize(state.req,'read'); } catch {res.destroy();return;}
    if (res.writableLength > 0) {if (!state.blockedAt) state.blockedAt = Date.now();if (Date.now()-state.blockedAt > 5000) res.destroy();return;}
    state.blockedAt = 0;
    const message = (event:string) => `id: ${feedEpoch}:${feedSequence}\nevent: ${event}\ndata: ${feedSignature}\n\n`;
    const first = feedHistory[0]?.sequence ?? feedSequence;
    if (state.lastSequence === undefined) {
      const cursor = state.req.headers['last-event-id'], prefix = feedEpoch + ':';
      const sequence = typeof cursor === 'string' && cursor.startsWith(prefix) ? Number(cursor.slice(prefix.length)) : NaN;
      if (typeof cursor === 'string' && cursor === prefix + sequence && Number.isSafeInteger(sequence) && sequence >= first-1 && sequence <= feedSequence) state.lastSequence = sequence;
      else {state.lastSequence = feedSequence;res.write(message('resync'));return;}
    }
    if (state.lastSequence < first-1) res.write(message('resync'));
    else res.write(feedHistory.filter(event => event.sequence > state.lastSequence!).map(event => event.body).join('') || ': heartbeat\n\n');
    state.lastSequence = feedSequence;
  };
  const feedTick = () => {advanceFeed();for (const res of streams) deliverFeed(res);};
  const feedTimer = setInterval(feedTick,options.feedIntervalMs ?? 1000);feedTimer.unref();
  let feedScheduled = false;
  const unlistenFeed = owner.onCommit(() => {
    // Deferred outside the commit call so a burst of commits triggers one fan-out.
    if (streams.size === 0 || feedScheduled) return;
    feedScheduled = true;
    setImmediate(() => {feedScheduled = false;feedTick();});
  });
  const authenticateConfigured = (token:string):Credential|null => {
    if (!/^[A-Za-z0-9_-]{43}(?![\s\S])/.test(token)) return null;
    const digest = createHash('sha256').update(token).digest();
    return currentCredentials.find(c => timingSafeEqual(digest,Buffer.from(c.digest,'hex'))) ?? null;
  };
  const authenticate = (token:string):Credential|null => {
    pruneBrowser();
    const configured=authenticateConfigured(token);if(configured)return configured;
    if(!/^[A-Za-z0-9_-]{43}$/.test(token))return null;
    return browserSessions.get(createHash('sha256').update(token).digest('hex'))?.credential??null;
  };
  // Authorization can precede a request body or an MCP call by an await. Before any effect, re-check that the principal is still
  // the current configured credential or a live browser session, so retirement, rotation or a scope change applies to late work.
  const live = (principal:Credential) => {
    pruneBrowser();
    if (browserSessions.get(principal.digest)?.credential === principal || currentCredentials.includes(principal)) return;
    throw new HttpError('unauthenticated',401);
  };
  const authorize = (req: IncomingMessage, scope: Scope, device?: string): Credential => {
    const token = req.headers.authorization;
    const principal = typeof token === 'string' && token.startsWith('Bearer ') ? authenticate(token.slice(7)) : null;
    if (!principal) throw new HttpError('unauthenticated',401);
    if (!sameOrigin(req) || !principal.scopes.includes(scope) || (device !== undefined && !principal.devices.includes(device))) throw new HttpError('forbidden',403);
    if (req.method !== 'GET' && req.headers['x-pixoo-request'] !== '1') throw new HttpError('forbidden',403);
    return principal;
  };
  async function command(principal: Credential, input: unknown) {
    live(principal);
    if (!object(input) || typeof input.requestId !== 'string' || input.requestId.length > 100) throw new HttpError('invalid-input',400);
    const keys = input.operation === 'label' ? ['operation','requestId','identity','label'] : input.operation === 'acknowledge' ? ['operation','requestId','identity','noticeId','consumerId'] : input.operation === 'recover-approval' ? ['operation','requestId','identity','turnId','expectedRevision'] : ['operation','requestId'];
    if (!exact(input,keys) || !['label','acknowledge','recover-approval','quiesce'].includes(input.operation as string)) throw new HttpError('invalid-input',400);
    if (input.operation !== 'quiesce' && (!object(input.identity) || !exact(input.identity,['provider','client','hostId','sourceId','sessionId']) ||
        !['codex','claude'].includes(input.identity.provider as string) || !['cli','desktop','code'].includes(input.identity.client as string) ||
        !id(input.identity.hostId) || !id(input.identity.sourceId) || !id(input.identity.sessionId))) throw new HttpError('invalid-input',400);
    if (input.operation === 'label' && input.label !== null && !validDisplayText(input.label,80)) throw new HttpError('invalid-input',400);
    if (input.operation === 'acknowledge' && (!id(input.noticeId) || !options.consumers.some(c => c.id === input.consumerId))) throw new HttpError('invalid-input',400);
    if (input.operation === 'recover-approval' && (!id(input.turnId) || !Number.isSafeInteger(input.expectedRevision) || (input.expectedRevision as number)<0)) throw new HttpError('invalid-input',400);
    if (input.operation === 'quiesce' && !principal.scopes.includes('admin')) throw new HttpError('forbidden',403);
    if (staged && input.operation !== 'quiesce') throw new HttpError('owner-quiesced',503);
    return replay.submit(principal.id,input.requestId,canonical(input),async () => {
      if (input.operation === 'label') return owner.setLabel(input.identity as Identity,input.label as string | null);
      if (input.operation === 'acknowledge') return owner.acknowledge(input.identity as Identity,input.noticeId as string,input.consumerId as string);
      if (input.operation === 'recover-approval') return owner.recoverApproval(input.identity as Identity,input.turnId as string,input.expectedRevision as number);
      // Persist before releasing an export, including if export subsequently fails.
      lease!.setFence(true); activationAllowed=false; return exported ??= owner.exportState();
    });
  }
  const sessions = (principal:Credential, query='', provider?:string,version:'1.0'|'1.1'|'1.2'='1.0') => {
    const current = snapshot(version);
    live(principal);
    return {apiVersion:'1.0',ownerId:options.ownerId,connection:'current',snapshot:current,admissionRejected:rejected,nextRequestId:replay.ticket(principal.id),
      matches:current.sessions.filter(s => (!provider || s.identity.provider === provider) && [s.label,s.title?.value,s.project,s.identity.sessionId].some(text=>text?.toLowerCase().includes(query.toLowerCase()))).map(s=>s.identity)};
  };
  const server = createServer({maxHeaderSize:8192,requestTimeout:3000,headersTimeout:3000},(req,res) => {
    void (async () => {
      if (closing || active >= 32) { rejected = Math.min(Number.MAX_SAFE_INTEGER,rejected+1);json(res,503,{error:{code:'capacity'}});return; }
      active++;
      const timer = setTimeout(() => res.destroy(),3000);
      let streaming = false;
      try {
        if (!req.url?.startsWith('/') || req.url.startsWith('//')) throw new HttpError('invalid-input',400);
        const url = new URL(req.url,origin), path = url.pathname;
        if (url.origin !== origin) throw new HttpError('invalid-input',400);
        if (req.method === 'GET' && !url.search && ['/', '/dashboard.js', '/dashboard.css'].includes(path)) {
          if (!sameOrigin(req)) throw new HttpError('forbidden',403);
          const asset = path === '/' ? 'index.html' : path.slice(1);
          const bytes = await readFile(new URL('../public/' + asset,import.meta.url)).catch(()=>null);
          if (!bytes) throw new HttpError('not-found',404);
          res.writeHead(200,{'content-type':asset.endsWith('.html')?'text/html; charset=utf-8':asset.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','content-security-policy':"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"});
          res.end(bytes);return;
        }
        if (path === '/mcp') {
          if (!mcp || url.search) throw new HttpError('not-found',404);
          await mcp.handle(req,res);return;
        }
        if(req.method==='POST'&&path==='/api/dashboard/v1/launch'&&!url.search){
          if(!sameOrigin(req,{requireOrigin:true,sites:[undefined,'same-origin']})||req.headers['x-pixoo-request']!=='1')throw new HttpError('forbidden',403);
          const input=await body(req,128);
          if(!object(input)||!exact(input,['code'])||typeof input.code!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(input.code))throw new HttpError('unauthenticated',401);
          pruneBrowser();const expiry=launchCodes.get(input.code);if(!expiry||expiry<=Date.now())throw new HttpError('unauthenticated',401);
          launchCodes.delete(input.code);
          json(res,200,openBrowserSession());return;
        }
        if(req.method==='POST'&&path==='/api/dashboard/v1/session'&&!url.search){
          // Off unless configured, like MCP. On, any same-origin loopback page gets a launcher-equivalent session (Hub #276).
          if(options.browserAccess!=='trusted-loopback')throw new HttpError('not-found',404);
          if(!sameOrigin(req,{requireOrigin:true,sites:[undefined,'same-origin']})||req.headers['x-pixoo-request']!=='1')throw new HttpError('forbidden',403);
          const input=await body(req,16);if(!object(input)||!exact(input,[]))throw new HttpError('invalid-input',400);
          pruneBrowser();json(res,200,openBrowserSession());return;
        }
        const route = /^\/api\/controllers\/v1\/([A-Za-z0-9_.-]{1,128})\/(snapshot|commands)$/.exec(path);
        const integrationRoute = /^\/api\/controllers\/v1\/([A-Za-z0-9_.-]{1,128})\/integration\/(snapshot|geometry|commands|receipt|cancel)$/.exec(path);
        const lightingRoute = /^\/api\/controllers\/v1\/([A-Za-z0-9_.-]{1,128})\/lighting\/(snapshot|commands)$/.exec(path);
        const scope = path === '/api/hub/v1/authority' && ['read','control','ingest'].includes(url.searchParams.get('scope') ?? '') ? url.searchParams.get('scope') as Scope : req.method === 'GET' ? 'read' : path === '/api/monitor/v1/events' ? 'ingest' : 'control';
        const principal = authorize(req,scope,route?.[1] ?? integrationRoute?.[1] ?? lightingRoute?.[1] ?? (path === '/api/playback/v1/snapshot' ? playback?.sourceId : undefined));
        // Every write reads its body after authorization; a principal retired meanwhile sends nothing.
        const admitted = async (maximum:number) => {const value = await body(req,maximum);live(principal);return value;};
        if(req.method==='POST'&&path==='/api/dashboard/v1/logout'&&!url.search){
          const input=await body(req,16);if(!object(input)||!exact(input,[]))throw new HttpError('invalid-input',400);
          // A configured credential has no browser session to end: its tickets, retained results and streams stay.
          if(browserSessions.get(principal.digest)?.credential.id===principal.id)retireBrowser(principal.digest);
          json(res,200,{disconnected:true});
        } else if (req.method === 'GET' && path === '/api/dashboard/v1/context' && !url.search) {
          json(res,200,{apiVersion:'1.0',control:principal.scopes.includes('control'),consumers:options.consumers.map(c=>c.id),...(playbackId && principal.devices.includes(playbackId) ? {playback:{sourceId:playbackId}} : {}),components:[...clients.values()].filter(c=>principal.devices.includes(c.config.id)).map(c=>({...c.status(),...(editorLinks[c.config.id]?{editorUrl:editorLinks[c.config.id]}:{})}))});
        } else if (req.method === 'GET' && path === '/api/hub/v1/authority' && [...url.searchParams.keys()].length === 1 && ['read','control','ingest'].includes(url.searchParams.get('scope') ?? '')) {
          authorize(req,url.searchParams.get('scope') as Scope);json(res,200,{ownerId:options.ownerId,scope:url.searchParams.get('scope')});
        } else if (req.method === 'GET' && path === '/api/monitor/v1/sessions') {
          const version=url.searchParams.get('snapshotVersion')??'1.0';
          if (!['1.0','1.1','1.2'].includes(version)||url.searchParams.getAll('snapshotVersion').length>1||
              [...url.searchParams.keys()].some(k => !['q','provider','snapshotVersion'].includes(k)) || (url.searchParams.get('q')?.length ?? 0) > 120 ||
              (url.searchParams.has('provider') && !['codex','claude'].includes(url.searchParams.get('provider')!))) throw new HttpError('invalid-input',400);
          const view = sessions(principal,url.searchParams.get('q') ?? '',url.searchParams.get('provider') ?? undefined,version as '1.0'|'1.1'|'1.2');
          if(url.searchParams.has('q')||url.searchParams.has('provider'))json(res,200,view);
          else {const {matches,...envelope}=view;json(res,200,envelope);}
        } else if (req.method === 'GET' && path === '/api/hub/v1/health' && !url.search) {
          const current = snapshot();
          json(res,current.collector === 'running' ? 200 : 503,{apiVersion:'1.0',ownerId:options.ownerId,collector:current.collector,admission:staged?'fenced':'open',revision:current.revision,devices:[...clients.values()].map(c => c.status())});
        } else if (req.method === 'POST' && path === '/api/monitor/v1/events' && !url.search) {
          if (staged) throw new HttpError('owner-quiesced',503);
          let input=await admitted(2048);
          const checked=validateEvent(input);
          if(codexDesktop&&checked.ok&&checked.value.identity.client==='desktop'&&checked.value.identity.hostId===codexDesktop.hostId&&checked.value.identity.sourceId===codexDesktop.sourceId)input=await enrichCodexTitle(checked.value,codexDesktop.home);
          live(principal); // Enrichment may yield while this credential is revoked.
          const result = await owner.ingest(input);
          json(res,result.ok ? 200 : result.code === 'invalid-event' ? 400 : result.code === 'capacity' ? 429 : 503,result);
        } else if (req.method === 'POST' && path === '/api/monitor/v1/commands' && !url.search) {
          json(res,200,await command(principal,await admitted(65536)));
        } else if (req.method === 'GET' && path === '/api/monitor/v1/changes' && !url.search) {
          if (streams.size >= 16) throw new HttpError('capacity',429);
          streaming = true;clearTimeout(timer); streams.add(res);streamOwners.set(res,principal.id);
          streamState.set(res,{req,blockedAt:0});
          res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-store','x-content-type-options':'nosniff'});
          advanceFeed();deliverFeed(res);
          res.once('close',() => {streams.delete(res);streamOwners.delete(res);streamState.delete(res);});
        } else if (playback && req.method === 'GET' && path === '/api/playback/v1/snapshot' && !url.search) {
          json(res,200,playback.snapshot());
        } else if (playback && req.method === 'POST' && path === '/api/playback/v1/commands' && !url.search) {
          // A staged migration destination must not become a second playback writer.
          if (staged) throw new HttpError('owner-quiesced',503);
          const response = await playback.command(await admitted(1024),principal);json(res,response.status,response.body);
        } else if (integrationRoute) {
          const client = clients.get(integrationRoute[1]);if (!client) throw new HttpError('unknown-device',404);
          const operation = integrationRoute[2];
          if (req.method === 'GET' && operation === 'snapshot' && !url.search) json(res,200,await client.integrationSnapshot());
          else if (req.method === 'GET' && operation === 'geometry' && !url.search) json(res,200,await client.integrationGeometry());
          else if (req.method === 'GET' && operation === 'receipt' && [...url.searchParams.keys()].length === 2 && url.searchParams.has('epoch') && /^[0-9]+$/.test(url.searchParams.get('sequence') ?? ''))
            {const response = await client.integrationReceipt({epoch:url.searchParams.get('epoch'),sequence:Number(url.searchParams.get('sequence'))});json(res,response.status,response.body);}
          else if (req.method === 'POST' && !url.search && operation === 'commands') {const receipt = await client.integrationCommand(await admitted(65536));json(res,receipt.status,receipt.body);}
          else if (req.method === 'POST' && !url.search && operation === 'cancel') {const response = await client.integrationCancel(await admitted(65536));json(res,response.status,response.body);}
          else throw new HttpError('invalid-input',400);
        } else if (lightingRoute && !url.search && ((req.method === 'GET' && lightingRoute[2] === 'snapshot') || (req.method === 'POST' && lightingRoute[2] === 'commands'))) {
          // LIFX color and temperature: the owner's typed lifx-light profile, never a controller v1 extension.
          const client = clients.get(lightingRoute[1]);if (!client) throw new HttpError('unknown-device',404);
          if (lightingRoute[2] === 'snapshot') json(res,200,await client.lightingSnapshot());
          else {const response = await client.lightingCommand(await admitted(65536));json(res,response.status,response.body);}
        } else if (route && !url.search && ((req.method === 'GET' && route[2] === 'snapshot') || (req.method === 'POST' && route[2] === 'commands'))) {
          const client = clients.get(route[1]);if (!client) throw new HttpError('unknown-device',404);
          if (route[2] === 'snapshot') json(res,200,await client.snapshot());
          else {const response = await client.command(await admitted(65536));json(res,response.status,response.body);}
        } else throw new HttpError('not-found',404);
      } catch (error) {
        const safe = error instanceof HttpError ? error : new HttpError('unavailable',503);
        if (!res.headersSent) json(res,safe.status,{error:{code:safe.code}});else res.destroy();
      } finally {active--;if (!streaming) {res.once('close',() => clearTimeout(timer));res.once('finish',() => clearTimeout(timer));}}
    })().catch(() => res.destroy());
  });
  server.maxConnections = 64;
  server.keepAliveTimeout = 1000;
  try {
    await new Promise<void>((resolve,reject) => {server.once('error',reject);server.listen(options.port ?? 0,'127.0.0.1',() => {server.off('error',reject);resolve();});});
  } catch (error) { await owner.shutdown();throw error; }
  const port = (server.address() as {port:number}).port;
  origin = `http://127.0.0.1:${port}`;hosts = [`127.0.0.1:${port}`,`localhost:${port}`];
  try {
    if (options.mcp) mcp = createHubMcp({origin,clients,authenticate:authenticateConfigured,principal:(id,scope,device) => {
      const value=currentCredentials.find(c=>c.id===id);
      if (!value || !value.scopes.includes(scope) || (device !== HOST_SERVICE && !value.devices.includes(device))) throw new HttpError('forbidden',403);
      return value;
    },sessions:(principal,query,provider)=>sessions(principal,query,provider,'1.2'),command,...(playbackId ? {playback:{sourceId:playbackId,
      // MCP is mounted before playback starts; until then the source is unavailable and nothing is sent.
      snapshot:() => {if (!playback) throw new HttpError('source-unavailable',503);return playback.snapshot();},
      command:async (principal:Credential,input:unknown) => {
        // Like the HTTP route: a staged migration destination must not become a second playback writer.
        if (staged) throw new HttpError('owner-quiesced',503);
        if (!playback) throw new HttpError('source-unavailable',503);
        return playback.command(input,principal);
      }}} : {})});
    closeBrowserLaunch=await startBrowserLaunch(options.directory,issueLaunch);
  } catch(error) {
    clearInterval(feedTimer);unlistenFeed();
    await mcp?.close().catch(()=>{});await new Promise<void>(resolve=>server.close(()=>resolve()));await owner.shutdown();throw error;
  }
  const desktopRead = codexDesktop && startDesktopRead(codexDesktop,owner,options.clock ?? Date.now,() => !staged && !closing && !exported);
  playback = playbackConfig && createPlayback(playbackConfig.id,playbackConfig.sources,options.clock ?? Date.now,options.clock ?? (() => performance.now()));
  let closePromise: Promise<void> | undefined;
  return {
    url:origin,
    ownerId:options.ownerId,
    directory:options.directory,
    validateCredentials(input:Credential[]) { credentials(input); },
    staged:() => staged,
    /** In-process counts for lifecycle tests. There is no HTTP route, and no credential or session content is included. */
    resources:() => ({requests:active,browserSessions:browserSessions.size,launchCodes:launchCodes.size,streams:streams.size,...replay.counts()}),
    prepareConsumers() {
      if(!staged||!activationAllowed||activating||closing||exported)throw new Error('activation-unavailable');
      preparingConsumers=true;
    },
    async activate(plan:ActivationPlan) {
      if (!staged || !activationAllowed || activating || closing) throw new Error('activation-unavailable');
      activating=true;activationAllowed=false;
      try {
        await prepareActivation(plan,origin,options.ownerId,options.consumers,snapshot);
        if (closing || exported || owner.snapshot().collector!=='running') throw new Error('activation-unavailable');
        lease!.setFence(false);staged=false;
      } finally {activating=false;preparingConsumers=false;}
    },

    replaceCredentials(input:Credential[]) {
      currentCredentials = credentials(input);
      launchCodes.clear();for (const digest of [...browserSessions.keys()]) retireBrowser(digest);
      for (const stream of streams) stream.destroy();
      for (const principal of replay.principals()) if (!currentCredentials.some(c => c.id === principal)) replay.retire(principal);
    },
    close(): Promise<void> {
      return closePromise ??= (async () => {
        closing = true;launchCodes.clear();for (const digest of [...browserSessions.keys()]) retireBrowser(digest);clearInterval(feedTimer);unlistenFeed();
        let launchFailure:unknown,playbackFailure:unknown;
        try{await closeBrowserLaunch?.();}catch(error){launchFailure=error;}
        await desktopRead?.close();
        try{await playback?.close();}catch(error){playbackFailure=error;}
        await mcp?.close();for (const client of clients.values()) client.close();for (const stream of streams) stream.destroy();
        await new Promise<void>((resolve,reject) => {server.close(error => error ? reject(error) : resolve());server.closeAllConnections();});
        await owner.shutdown();
        if(launchFailure)throw launchFailure;
        if(playbackFailure)throw playbackFailure;
      })();
    }
  };
}
